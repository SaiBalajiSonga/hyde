"""TFI Catan agent.

F (catanatron's ValueFunctionPlayer) scores every legal move with a 13-feature value function and
plays the best, one move ahead. We keep that evaluation but fix its main blind spot: a move that
looks bad on its own but enables a better position later in the SAME turn (a bank trade that
completes a settlement, for example). For the most promising moves we roll the turn forward
greedily and score the best position reachable before ending it.

Everything runs under a CPU budget derived from obs.cpu_left, and every decision is wrapped so an
error falls back to a plain one-ply choice, then to index 0.
"""
import json
import os
import random
import time

from catanatron.models.enums import ActionType
from catanatron.players.value import DEFAULT_WEIGHTS, base_fn

HERE = os.path.dirname(os.path.abspath(__file__))

# Search settings. Times are in seconds of the per-game CPU allowance.
CFG = dict(
    top_k=4,            # moves whose turn we roll forward
    rollout_depth=4,    # extra own moves per rollout
    cap_normal=0.020,   # most we spend on one ordinary decision
    cap_opening=0.060,  # initial placement has the most candidates
    spend_fraction=0.20,
    low_clock=0.080,    # below this, one-ply only
    weights={},
)


def load_cfg():
    """config.json beside this file, then TFI_CFG (a path, for local experiments only)."""
    cfg = dict(CFG)
    for path in (os.path.join(HERE, "config.json"), os.environ.get("TFI_CFG")):
        if path and os.path.exists(path):
            with open(path) as f:
                cfg.update(json.load(f))
    w = dict(DEFAULT_WEIGHTS)
    w.update(cfg["weights"])
    cfg["weights"] = w
    return cfg


class Agent:
    def __init__(self):
        self.rng = random.Random(0)
        self.cfg = load_cfg()
        self.value = base_fn(self.cfg["weights"])
        self.end_turn = ActionType.END_TURN

    # ------------------------------------------------------------------ entry point
    def decide(self, obs, playable_actions) -> int:
        t0 = time.perf_counter()
        n = len(playable_actions)
        try:
            i = self._decide(obs, playable_actions, t0)
            if isinstance(i, int) and 0 <= i < n:
                return i
        except Exception:
            pass
        try:
            return self._one_ply_only(obs, playable_actions)
        except Exception:
            return 0

    # ------------------------------------------------------------------ search
    def _budget(self, obs, playable_actions):
        left = obs.cpu_left if obs.cpu_left is not None else 1.0
        opening = obs.turn < 4 or any(
            a.action_type == ActionType.BUILD_SETTLEMENT for a in playable_actions[:1]
        ) and len(playable_actions) > 15
        cap = self.cfg["cap_opening"] if opening else self.cfg["cap_normal"]
        return min(cap, self.cfg["spend_fraction"] * left), left

    def _decide(self, obs, actions, t0):
        budget, left = self._budget(obs, actions)
        deadline = t0 + budget
        world = obs.sample_world(self.rng)
        me = obs.me

        # One ply: the value of the position right after each move.
        children = []
        scores = []
        for a in actions:
            g = world.copy()
            try:
                g.execute(a, validate_action=False)
                v = self.value(g, me)
            except Exception:
                g, v = None, float("-inf")
            children.append(g)
            scores.append(v)

        if left < self.cfg["low_clock"] or self.cfg["top_k"] == 0:
            return max(range(len(actions)), key=scores.__getitem__)

        # Same-turn rollouts for the best few moves that keep the turn going.
        order = sorted(range(len(actions)), key=scores.__getitem__, reverse=True)
        final = list(scores)
        for i in order[:self.cfg["top_k"]]:
            if time.perf_counter() > deadline:
                break
            g = children[i]
            if g is None or actions[i].action_type == self.end_turn:
                continue
            final[i] = max(scores[i], self._rollout(g, me, deadline))
        return max(range(len(actions)), key=final.__getitem__)

    def _rollout(self, g, me, deadline):
        """Greedy ascent through our own remaining moves this turn. Returns the best value seen."""
        best = float("-inf")
        for _ in range(self.cfg["rollout_depth"]):
            if g.winning_color() is not None:
                return self.value(g, me)
            if g.state.current_color() != me:
                break
            acts = g.playable_actions
            nxt, nxt_v = None, float("-inf")
            for a in acts:
                if time.perf_counter() > deadline:
                    return best
                if a.action_type == self.end_turn:
                    continue
                c = g.copy()
                try:
                    c.execute(a, validate_action=False)
                    v = self.value(c, me)
                except Exception:
                    continue
                if v > nxt_v:
                    nxt, nxt_v = c, v
            if nxt is None:
                break
            best = max(best, nxt_v)
            g = nxt
        return best

    def _one_ply_only(self, obs, actions):
        world = obs.sample_world(self.rng)
        best_i, best_v = 0, None
        for i, a in enumerate(actions):
            g = world.copy()
            try:
                g.execute(a, validate_action=False)
                v = self.value(g, obs.me)
            except Exception:
                continue
            if best_v is None or v > best_v:
                best_i, best_v = i, v
        return best_i
